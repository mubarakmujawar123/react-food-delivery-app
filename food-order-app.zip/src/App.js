import React, { useState } from "react";
import "./App.css";
import Header from "./components/Layout/Header";
import Meals from "./components/Meals/Meals";
import Cart from "./components/Cart/Cart";
import CartProvider from "./store/CartProvider";
function App() {
  const [isCartShown, setIsCartShowm] = useState(false);
  const showCartHandler = () => {
    setIsCartShowm(true);
  };
  const hideCartHandler = () => {
    console.log("In Hide");
    setIsCartShowm(false);
  };
  return (
    <CartProvider>
      {isCartShown && <Cart onClose={hideCartHandler} />}
      <Header onShowCart={showCartHandler}></Header>
      <main>
        <Meals></Meals>
      </main>
    </CartProvider>
  );
}

export default App;
